package com.me.asm;

public class Const
{
    public static final String typeInt = "Ljava/lang/Integer;";
    public static final String typeString = "Ljava/lang/String;";
    public static final String typeDate = "Ljava/util/Date;";
    public static final String typeFloat = "Ljava/lang/Float;";
    public static final String packagePath ="com/me/asm";
}   
