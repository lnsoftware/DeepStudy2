package com.taozeyu.taolan.intermediatecode;

public class IntermediateCodeExpression extends Exception {

    private static final long serialVersionUID = -5303146379867837864L;

    public IntermediateCodeExpression() {};

    public IntermediateCodeExpression(String msg) {
        super(msg);
    };
}
