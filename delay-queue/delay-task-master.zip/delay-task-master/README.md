# delay-task
时间轮算法、redis的zset、redis的key过期订阅事件等几种方式实现的延时任务调度

TODO
===========
添加Task任务自身的任务状态，如取消<br/>
保证任务可用，需要落盘机制？
