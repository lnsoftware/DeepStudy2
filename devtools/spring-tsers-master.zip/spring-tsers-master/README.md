Example project for blogpost: https://medium.com/@lhartikk/development-environment-in-spring-boot-with-docker-734ad6c50b34
