package org.tsers.springtsers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsersApplication.class, args);
	}

}
