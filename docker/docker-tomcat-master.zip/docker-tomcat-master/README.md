# docker-tomcat

继承自官方tomcat镜像tomcat:8.5。内置openjdk8 jre。

改进：

增加阿里云镜像源(mirrors.aliyun.com)

修改locale为zh_CN.UTF-8

修改timezone为Asia/Shanghai
