# grpc-demo  introduces using grpc

1.Introduction   grpc

2.Simple demo of grpc 

3.Using OpenSSL encryption of grpc transport

4.How  to  using protobuf  oneof

5.How  to  using  client-stream and service-stream

6.Add client and server interceptor

7.How to using NameResovler

8.How to using RoundRobinLoadBalancer

9.Using grpc proxy


## Introduction   grpc

gRPC is a modern open source high performance RPC framework that can run in any environment. It can efficiently co nnect services in and across data centers with pluggable support for load balancing, tracing, health checking and authentication. It is also applicable in last mile of distributed computing to connect devices, mobile applications and browsers to backend services.

![image](http://www.grpc.io/grpc.github.io/img/landing-2.svg)

### Learning materials
[grpc-java](https://github.com/grpc/grpc-java)

[grpc-home](http://www.grpc.io/)

[grpc-chines](http://doc.oschina.net/grpc?t=60134/)

[grpc-learning](https://skyao.gitbooks.io/leaning-grpc/content/)  thanks  @skyao 
