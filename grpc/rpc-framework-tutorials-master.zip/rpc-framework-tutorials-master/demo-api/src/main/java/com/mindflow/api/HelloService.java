package com.mindflow.api;

public interface HelloService {

	String sayHi(String msg);
}
