package com.mindflow.grpc;

/**
 * @author Ricky Fung
 */
public class App {
}
