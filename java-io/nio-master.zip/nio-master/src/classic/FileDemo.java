package classic;

import java.io.File;

/**
 * Created by yifan on 3/28/17.
 */
public class FileDemo {

    public static void main(String[] args){
        File file1 = new File("/x/y");
        File file2 = new File("C:\\temp\\x.dat");
    }
}
