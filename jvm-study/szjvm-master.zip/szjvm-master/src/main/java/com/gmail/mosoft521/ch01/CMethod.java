package com.gmail.mosoft521.ch01;

public class CMethod {
//    public static void new (){
//    }

    public static void 打印() {
        System.out.println("中文方法");
    }

    public static void main(String[] args) {
        打印();
    }
}
/*
中文方法
 */