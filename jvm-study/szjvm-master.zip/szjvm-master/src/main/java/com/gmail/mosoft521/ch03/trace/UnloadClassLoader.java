package com.gmail.mosoft521.ch03.trace;

public class UnloadClassLoader extends ClassLoader {
}