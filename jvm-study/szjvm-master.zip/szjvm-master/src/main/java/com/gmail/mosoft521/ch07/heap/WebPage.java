package com.gmail.mosoft521.ch07.heap;

public class WebPage {
    private String url;
    private String content;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String cotent) {
        this.content = cotent;
    }
}