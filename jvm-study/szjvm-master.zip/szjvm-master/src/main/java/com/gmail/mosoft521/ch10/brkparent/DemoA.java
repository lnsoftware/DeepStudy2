package com.gmail.mosoft521.ch10.brkparent;

public class DemoA {

}
