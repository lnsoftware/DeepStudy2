package com.gmail.mosoft521.ch10.clshot;

public class DemoA {
    public void hot() {
        System.out.println("NewDemoA");
    }
}
