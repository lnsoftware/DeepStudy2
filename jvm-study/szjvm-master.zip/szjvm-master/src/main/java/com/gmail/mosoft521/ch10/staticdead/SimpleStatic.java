package com.gmail.mosoft521.ch10.staticdead;

public class SimpleStatic {
    public static int id = 1;
    public static int number;

    static {
        number = 4;
    }
}