package com.gmail.mosoft521.ch10.staticdead;

public class StaticFinalClass {
    public static final int i = 1;
    public static final int j = 2;
}