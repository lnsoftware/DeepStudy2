package com.gmail.mosoft521.ch11.aop.securitycheck;

public class Account {
    public void operation() {
        System.out.println("operation...");
    }
}