package com.gmail.mosoft521.ch11.aop.securitycheck;

public class RunAccountMain {
    public static void main(String[] args) {
        Account account = new Account();
        account.operation();
    }
}