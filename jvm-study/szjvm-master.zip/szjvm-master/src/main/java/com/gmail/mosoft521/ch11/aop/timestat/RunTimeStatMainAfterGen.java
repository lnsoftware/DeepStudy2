package com.gmail.mosoft521.ch11.aop.timestat;

public class RunTimeStatMainAfterGen {
    public static void main(String[] args) {
        Account account = new Account();
        account.operation();
    }
}
