package com.gmail.mosoft521.ch11.compile;

public class FinalFlag {
    public static final boolean flag = true;
}