package com.gmail.mosoft521.ch11.inv;

public class Simple {

    public static void main(String[] args) {
        System.out.println(new Object().toString());
    }
}