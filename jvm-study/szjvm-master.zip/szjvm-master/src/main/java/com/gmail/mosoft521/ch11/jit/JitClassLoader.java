package com.gmail.mosoft521.ch11.jit;

public class JitClassLoader extends ClassLoader {
}