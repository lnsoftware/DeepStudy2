package com.gmail.mosoft521.ch11.jit.deopt;

public class DBWriter {
    public void write() {
        "DBWriter".toCharArray();
    }
}