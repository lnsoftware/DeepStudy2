Expected output: nothing. GRUB simply boots correctly.
