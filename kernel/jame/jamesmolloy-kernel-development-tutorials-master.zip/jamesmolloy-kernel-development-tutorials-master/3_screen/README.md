Expected output:

    Hello world!
