Expected output:

    Hello world!
    received interrupt: 3
    received interrupt: 4
