Expected output:

    Tick: 1
    Tick: 2
    Tick: 3
    Tick: 4
    ...

TODO: if I remove all IRQs except 0, it works, but I get an int13 when I hit enter on QEMU.
