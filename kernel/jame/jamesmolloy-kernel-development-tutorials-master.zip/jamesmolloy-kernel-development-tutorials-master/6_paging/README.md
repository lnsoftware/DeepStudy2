TODO get working.

Expected output:

    Hello, paging world!
    Page fault ( present ) at 0x0xa0000000
    PANIC(Page fault) at paging.c:201

Actual outcome: system reboots.
