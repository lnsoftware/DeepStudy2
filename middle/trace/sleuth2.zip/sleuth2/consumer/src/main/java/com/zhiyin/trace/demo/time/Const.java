package com.zhiyin.trace.demo.time;

/**
 * Created by wangqinghui on 2017/9/24.
 */
public class Const {

    public static String before = "curtime-service";
    public static String start = "http-remotetime";

}
