

ab -n 200 -c 20  http://localhost:8080/defer


异步入门

http://xpadro.blogspot.com/2015/07/understanding-callable-and-spring.html


servlet asyn 例子
http://www.importnew.com/8864.html

http://blog.csdn.net/wangyangzhizhou/article/details/53207966

https://zhuanlan.zhihu.com/p/22018499