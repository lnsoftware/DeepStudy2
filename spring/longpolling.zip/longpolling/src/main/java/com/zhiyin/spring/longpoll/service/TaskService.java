package com.zhiyin.spring.longpoll.service;

public interface TaskService {

    String execute();
}
