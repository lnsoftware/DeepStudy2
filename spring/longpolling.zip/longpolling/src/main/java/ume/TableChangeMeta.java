package ume;

/**
 * Created by hg on 2017/5/17.
 */
public class TableChangeMeta {

//    private List<String>

    private String tableName;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
