# Simple Spring
A simple Spring framwork.

## Feature
**IoC Feature:**
* [Basic bean](https://github.com/Yikun/simple-spring/blob/master/src/test/java/com/springstudy/simplespring/TestIoC.java#L12)
* [Bean with property](https://github.com/Yikun/simple-spring/blob/master/src/test/java/com/springstudy/simplespring/TestIoC.java#L29)

## Download
```bash
git clone https://github.com/Yikun/simple-spring.git
```

## Test
```bash
mvn test
```
