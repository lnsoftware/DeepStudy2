package com.springstudy.simplespring;

public class HelloWorld {
	private String msg = "Hello World!";
	
	public String sayHello() {
		return msg;
	}
}
