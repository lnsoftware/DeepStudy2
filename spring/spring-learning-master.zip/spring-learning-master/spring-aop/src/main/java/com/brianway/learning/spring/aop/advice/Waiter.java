package com.brianway.learning.spring.aop.advice;

public interface Waiter {
    void greetTo(String name);

    void serveTo(String name);
}
