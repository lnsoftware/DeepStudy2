package com.brianway.learning.spring.aop.advisor;

import org.springframework.aop.support.RegexpMethodPointcutAdvisor;

public class GreetingRegexpAdvisor extends RegexpMethodPointcutAdvisor {

}
