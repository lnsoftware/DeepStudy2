package com.brianway.learning.spring.aop.aspectj;

/**
 * Created by brian on 16/8/18.
 */
public interface Seller {
    int sell(String goods, String clientName);
}
