package com.brianway.learning.spring.aop.instrument;

/**
 * Created by brian on 16/8/22.
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("I'm in main() of Test ...");
    }
}
