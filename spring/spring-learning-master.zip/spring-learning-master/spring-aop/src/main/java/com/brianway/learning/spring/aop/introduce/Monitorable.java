package com.brianway.learning.spring.aop.introduce;

public interface Monitorable {
    void setMonitorActive(boolean active);
}
