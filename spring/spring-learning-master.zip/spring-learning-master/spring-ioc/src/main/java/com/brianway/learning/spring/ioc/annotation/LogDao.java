package com.brianway.learning.spring.ioc.annotation;

//@Repository
public class LogDao {

}
