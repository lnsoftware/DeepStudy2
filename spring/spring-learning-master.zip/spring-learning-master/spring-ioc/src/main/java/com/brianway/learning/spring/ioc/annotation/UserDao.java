package com.brianway.learning.spring.ioc.annotation;

import org.springframework.stereotype.Component;

@Component("userDao")
public class UserDao {

}
