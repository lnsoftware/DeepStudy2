package com.brianway.learning.spring.ioc.conf;

public class UserDao {

}
