package com.brianway.learning.spring.ioc.ditype;

public class Office {

}
