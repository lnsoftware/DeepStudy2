package com.brianway.learning.spring.ioc.example;

/**
 * Created by Brian on 2016/5/12.
 */
public interface GeLi {
    void responseAsk(String response);
}
