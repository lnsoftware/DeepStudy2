package com.brianway.learning.spring.ioc.example;

/**
 * Created by Brian on 2016/5/12.
 */
public class LiuDeHua implements GeLi {
    public void responseAsk(String response) {
        System.out.println(response);
    }
}

