package xpadro.spring.web.service;

public interface TaskService {

    String execute();
}
