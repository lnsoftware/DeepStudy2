package xpadro.rest.ri.model;

public class TypeBItem extends Item {
	private static final long serialVersionUID = 1L;

	public TypeBItem() {}
	
	public TypeBItem(int id, float price) {
		super(id, price, "B");
	}
}
