package xpadro.rest.ri.resources;

public interface ItemResource {

}
